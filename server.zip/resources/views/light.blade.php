<form method="post" action="/fire">
        <button type="submit" name="value" value="1">ON</button>
        <button type="submit" name="value" value="0">OFF</button>
</form>