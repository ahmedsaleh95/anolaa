<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mailcode extends Model
{
    //
    protected $guarded = [];
    
}
