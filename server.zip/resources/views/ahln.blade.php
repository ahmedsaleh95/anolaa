<h1>Your Verfication Code is , <span style="color: red;">{{ $code }}</span></h1>
<br>
<p>Anolaa Team.</p>