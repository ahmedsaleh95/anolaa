<h1>Your Verfication Code is , <span style="color: red;"><?php echo e($code); ?></span></h1>
<br>
<p>Anolaa Team.</p>